<?php
include "connection.php";
error_reporting(0);

?>
<html>
<head>
  <title>REGISTRATION</title>
  <?php include 'links.php'?>
  
  <?php
   echo "<link rel='stylesheet' type='text/css' href='style.css' />";
  ?>
  
	
 
  
</head>
<body>
<div class="heading">
        <h1 class="heading"> REGISTER </h1>

    </div>
    <form action="" method="POST" onSubmit="return confirm('Do you want to submit?')">
        <div class="content">
            <label>First Name</label><br><br>
            <input type="text" id="fname" value="" name="fname" placeholder="  Enter your First Name" class="box"><br><br>
            <label>Last Name</label><br><br>
            <input type="text" id="lname" value="" name="lname" placeholder="  Enter your Last Name" class="box"><br><br>
            Age (18 or older) <br><br><input type="number" id="Age" value="" name="age" placeholder="  Enter your Age"
                class="box"><br><br>
            <label>Gender</label><br>
            <input type="radio" name="gender" value="male"> Male<br>
            <input type="radio" name="gender" value="female"> Female<br>
            <input type="radio" name="gender" value="Others"> Others<br><br>
            <label> Phone Number </label><br><br>
            <input type="phone number" id="phone number" value="" name="ph" placeholder="  Enter your phone number" 
                class="box"><br><br>
            <label> Email </label><br><br>
            <input type="email" id="email" value="" name="email" placeholder="  Enter your Email" class="box"><br><br>
            Aadhar Card Number <br><br><input type="text" id="number" value="" name="acn"
                placeholder="  Enter your Aadhar Card Number" class="box"><br> <br>
            City <br><br> <input type="place" id="place" value="" name="city" placeholder="  Enter your City" class="box"><br><br>
            <label> Select your State </label><br>

            <div class="option">


                <select name="state">
                    <option > Select your State </option>
                    <option >Andhra Pradesh</option>
                    <option >Arunachal Pradesh </option>
                    <option >Assam </option>
                    <option >Bihar </option>
                    <option >Chhattisgarh </option>
                    <option >Goa </option>
                    <option >Gujarat </option>
                    <option >Haryana </option>
                    <option >Himachal Pradesh </option>
                    <option >Jharkhand </option>
                    <option >Karnataka </option>
                    <option >Kerala </option>
                    <option >Madhya Pradesh</option>
                    <option >Maharashtra</option>
                    <option >Manipur </option>
                    <option >Meghalaya </option>
                    <option >Mizoram </option>
                    <option >Nagaland </option>
                    <option >Odisha </option>
                    <option >Punjab </option>
                    <option >Rajesthan </option>
                    <option >Sikkim </option>
                    <option >Tamil Nadu</option>
                    <option > Telangana</option>
                    <option >Tripura </option>
                    <option >Uttar Pradesh</option>
                    <option >Uttarakhand</option>
                    <option > West Bengal</option>



                </select>

                
            </div>
			<br>
				<br>
            
                Pin Code <br> <br><input type="text" value="" name="pc" placeholder="  Enter Your Pin Code"
                    class="box">
                    <br><br>
                
                    <div class="date">
                    <label> Select your Date</label><br>
                    <select name="date">
                        <option value="Select your Date" > Select your Date </option>
                        <option >11-July</option>
                        <option >12-July </option>
                        <option >13-July</option>
                        <option >14-July</option>
                        <option >15-July</option>
                        <option >16-July</option>
                        <option >17-July </option>
                    </Select>
                </div>
                <br>
				<br>
                <div class="slot">
                    <label> Select your Time Slot</label><br>
                    <select name="slot">
                        <option value="Select your Time Slot" > Select your Time Slot </option>
                        <option name="1">10AM-11AM</option>
                        <option name="2">11AM-12PM </option>
                        <option name="3">12PM-1PM</option>
                        <option name="4">1PM-2PM</option>
                        <option name="5">2PM-3PM</option>
                        <option name="6">3PM-4PM</option>
                        <option name="7">4PM-5PM </option>
                    </Select>
                </div>
            </div>
            <br><br>
            <div class="button">
           
                <center>
				
                    
				
                    <input type="submit" value="Register"  name="submit"  >
					
                  
					
                   </center>
                    
            </div>
      
       
    </form>
	
	 
</body>
</html>

<?php
    
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$ph=$_POST['ph'];
	$email=$_POST['email'];
	$acn=$_POST['acn'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$pc=$_POST['pc'];
	$date=$_POST['date'];
	$slot=$_POST['slot'];
	
	$query="INSERT INTO PEOPLE(fname,lname,age,gender,phonenumber,email,aadharcardnumber,city,state,pincode,date,timeslot) VALUES ('$fname','$lname','$age','$gender','$ph','$email','$acn','$city','$state','$pc','$date','$slot')";
	mysqli_query($con,$query);
	//$data=mysqli_query($con,$query);
	
	/*if($data){
		echo "data inserted";
	}
	else{
		echo "data not inserted";
	}*/
	
?>