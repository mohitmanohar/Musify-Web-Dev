<?php

$username="root";
$server='localhost';
$password="";
$db='vaccination';

 $con= mysqli_connect($server,$username,$password,$db);


?>